const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const User = require('../models/User');  // Ensure this line is present
const { registerUser, loginUser } = require('../controllers/authController');
router.post('/register', registerUser);
router.post('/login', loginUser);
// Define your routes here
router.get('/me', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id).select('-password');
        
        if (!user) {
            return res.status(404).json({ msg: 'User not found' });
        }

        res.json({
            user: user.id,
            // email: user.email
        });
    } catch (err) {
        console.error('Server Error:', err.message);
        res.status(500).send('Server error');
    }
});

module.exports = router;
